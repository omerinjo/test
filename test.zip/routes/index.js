const userRoutes = require('./user')

const routes = {
    userRoutes

};

module.exports = routes; 